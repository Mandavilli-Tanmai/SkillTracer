from django import forms

from .models import (
    Skill,
    Goal,
    Course,
    LearningLog,
    SkillProgress
)


class SkillForm(forms.ModelForm):

    class Meta:
        model = Skill
        fields = [
            'name',
            'category',
            'level',
            'progress',
            'target_date'
        ]

        widgets = {
            'target_date': forms.DateInput(
                attrs={'type': 'date'}
            ),
        }


class GoalForm(forms.ModelForm):

    class Meta:
        model = Goal
        fields = [
            'title',
            'description',
            'progress',
            'target_date'
        ]

        widgets = {
            'target_date': forms.DateInput(
                attrs={'type': 'date'}
            ),
        }


class CourseForm(forms.ModelForm):

    class Meta:
        model = Course
        fields = [
            'name',
            'platform',
            'status',
            'certificate'
        ]


class LearningLogForm(forms.ModelForm):

    class Meta:
        model = LearningLog
        fields = [
            'skill',
            'date',
            'hours',
            'description'
        ]

        widgets = {
            'date': forms.DateInput(
                attrs={'type': 'date'}
            ),
        }


class SkillProgressForm(forms.ModelForm):

    class Meta:
        model = SkillProgress
        fields = [
            'skill',
            'date',
            'progress'
        ]

        widgets = {
            'date': forms.DateInput(
                attrs={'type': 'date'}
            ),
        }