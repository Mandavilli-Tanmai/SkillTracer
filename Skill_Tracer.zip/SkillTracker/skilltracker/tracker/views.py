from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required

from .forms import (
    SkillForm,
    GoalForm,
    CourseForm,
    LearningLogForm,
    SkillProgressForm
)

from .models import (
    Skill,
    Goal,
    Course,
    LearningLog,
    SkillProgress
)


# =========================
# HOME
# =========================

def home(request):
    return render(request, 'home.html')


# =========================
# ADD SKILL
# =========================

@login_required
def add_skill(request):

    if request.method == 'POST':

        form = SkillForm(request.POST)

        if form.is_valid():

            skill = form.save(commit=False)

            skill.user = request.user

            skill.save()

            return redirect('/dashboard/')

    else:

        form = SkillForm()

    return render(
        request,
        'add_skill.html',
        {'form': form}
    )


# =========================
# DASHBOARD
# =========================

@login_required
def dashboard(request):

    # User's skills
    skills = Skill.objects.filter(
        user=request.user
    )

    # User's goals
    goals = Goal.objects.filter(
        user=request.user
    )

    # User's courses
    courses = Course.objects.filter(
        user=request.user
    )

    # User's learning logs
    logs = LearningLog.objects.filter(
        user=request.user
    ).order_by('-date')

    # User's skill progress history
    progress_history = SkillProgress.objects.filter(
        user=request.user
    ).select_related(
        'skill'
    ).order_by('date')

    # Calculate total learning hours
    total_hours = sum(
        log.hours for log in logs
    )

    return render(
        request,
        'dashboard.html',
        {
            'skills': skills,
            'goals': goals,
            'courses': courses,
            'logs': logs,
            'total_hours': total_hours,
            'progress_history': progress_history,
        }
    )


# =========================
# REGISTER
# =========================

def register(request):

    if request.method == 'POST':

        form = UserCreationForm(request.POST)

        if form.is_valid():

            form.save()

            return redirect('/accounts/login/')

    else:

        form = UserCreationForm()

    return render(
        request,
        'register.html',
        {'form': form}
    )


# =========================
# ADD GOAL
# =========================

@login_required
def add_goal(request):

    if request.method == 'POST':

        form = GoalForm(request.POST)

        if form.is_valid():

            goal = form.save(commit=False)

            goal.user = request.user

            goal.save()

            return redirect('/dashboard/')

    else:

        form = GoalForm()

    return render(
        request,
        'add_goal.html',
        {'form': form}
    )


# =========================
# ADD COURSE
# =========================

@login_required
def add_course(request):

    if request.method == 'POST':

        form = CourseForm(request.POST)

        if form.is_valid():

            course = form.save(commit=False)

            course.user = request.user

            course.save()

            return redirect('/dashboard/')

    else:

        form = CourseForm()

    return render(
        request,
        'add_course.html',
        {'form': form}
    )


# =========================
# ADD LEARNING LOG
# =========================

@login_required
def add_learning_log(request):

    if request.method == 'POST':

        form = LearningLogForm(request.POST)

        # Show only the logged-in user's skills
        form.fields['skill'].queryset = Skill.objects.filter(
            user=request.user
        )

        if form.is_valid():

            log = form.save(commit=False)

            log.user = request.user

            log.save()

            return redirect('/dashboard/')

    else:

        form = LearningLogForm()

        # Show only the logged-in user's skills
        form.fields['skill'].queryset = Skill.objects.filter(
            user=request.user
        )

    return render(
        request,
        'add_learning_log.html',
        {'form': form}
    )


# =========================
# ADD SKILL PROGRESS
# =========================

@login_required
def add_progress(request):

    if request.method == 'POST':

        form = SkillProgressForm(request.POST)

        # Show only the logged-in user's skills
        form.fields['skill'].queryset = Skill.objects.filter(
            user=request.user
        )

        if form.is_valid():

            progress = form.save(commit=False)

            progress.user = request.user

            progress.save()

            return redirect('/dashboard/')

    else:

        form = SkillProgressForm()

        # Show only the logged-in user's skills
        form.fields['skill'].queryset = Skill.objects.filter(
            user=request.user
        )

    return render(
        request,
        'add_progress.html',
        {'form': form}
    )