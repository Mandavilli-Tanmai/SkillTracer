from django.urls import path
from . import views


urlpatterns = [

    path(
        '',
        views.home,
        name='home'
    ),

    path(
        'add-skill/',
        views.add_skill,
        name='add_skill'
    ),

    path(
        'dashboard/',
        views.dashboard,
        name='dashboard'
    ),

    path(
        'register/',
        views.register,
        name='register'
    ),

    path(
        'add-goal/',
        views.add_goal,
        name='add_goal'
    ),

    path(
        'add-course/',
        views.add_course,
        name='add_course'
    ),

    path(
        'add-learning-log/',
        views.add_learning_log,
        name='add_learning_log'
    ),

    path(
        'add-progress/',
        views.add_progress,
        name='add_progress'
    ),
]