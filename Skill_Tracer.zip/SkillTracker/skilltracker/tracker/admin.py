from django.contrib import admin
from .models import Skill, Goal, Course, LearningLog, SkillProgress

admin.site.register(Skill)
admin.site.register(Goal)
admin.site.register(Course)
admin.site.register(LearningLog)
admin.site.register(SkillProgress)